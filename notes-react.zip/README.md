# notes-react

Submission Kelas Belajar Membuat Aplikasi Web dengan React di Dicoding

🗒️ [Sertifikat Kompetensi Belajar Membuat Aplikasi Web dengan React.pdf](https://www.dicoding.com/certificates/KEXL1R22RXG2)

## Screenshot

![Aplikasi Catatan React Js](/public/submission.png)
