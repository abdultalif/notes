import PropTypes from "prop-types";
import NoteList from "../components/NoteList";
import { useQuery } from "react-query";
import { getArchivedNotes } from "../utils/api";
import { translationArchive } from "../utils/translations";
import { useLanguage } from "../context/Language";
import SkeletonLoader from "../components/SkeletonLoader";

export default function ArchivedNotesPage() {
  const { language } = useLanguage();
  const { data, error, isLoading } = useQuery("notes", getArchivedNotes);

  if (isLoading) {
    return (
      <div>
        <h1 className="page-title">{translationArchive[language].title}</h1>
        <SkeletonLoader />
      </div>
    );
  }

  if (error) {
    return <p>Error: {error.message}</p>;
  }

  const archivedNotes = data.data.filter((note) => note.archived);

  return (
    <div>
      <h1>{translationArchive[language].title}</h1>
      {archivedNotes.length > 0 ? (
        <NoteList notes={archivedNotes} />
      ) : (
        <p className="note-empty">{translationArchive[language].empty}</p>
      )}
    </div>
  );
}
