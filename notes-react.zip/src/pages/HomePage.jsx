import PropTypes from "prop-types";
import NoteList from "../components/NoteList";
import { useLanguage } from "../context/Language";
import { translationHome } from "../utils/translations";
import { useQuery } from "react-query";
import { getActiveNotes } from "../utils/api";
import SkeletonLoader from "../components/SkeletonLoader";

export default function HomePage() {
  const { language } = useLanguage();

  const { data, error, isLoading } = useQuery("notes", getActiveNotes);

  if (isLoading) {
    return (
      <div>
        <h1 className="page-title">{translationHome[language].title}</h1>
        <SkeletonLoader />
      </div>
    );
  }

  if (error) {
    return <p>Error: {error.message}</p>;
  }

  const activeNotes = data.data.filter((note) => !note.archived);

  return (
    <div>
      <h1 className="page-title">{translationHome[language].title}</h1>
      {activeNotes.length > 0 ? (
        <NoteList notes={activeNotes} />
      ) : (
        <p className="note-empty">{translationHome[language].empty}</p>
      )}
    </div>
  );
}
